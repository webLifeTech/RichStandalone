import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { GlobalService } from '../../../services/global.service';
import { MatIconModule } from '@angular/material/icon';
import { ProgressBarMode, MatProgressBarModule } from '@angular/material/progress-bar';
import { Observable, Subscribable } from 'rxjs';

export type StepStatus = 'Completed' | 'Active' | 'Pending' | 'Partially Completed';

export interface ProgressStep {
  id: string;
  title: string;
  module: string;
  route: string;
  status: 'active' | 'pending' | 'completed';
  section: number;        // total sections
  completedSections: number[]; // sections done
  progress: number;       // calculated
}

@Component({
  selector: 'app-step-progress',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatProgressBarModule
  ],
  templateUrl: './step-progress.component.html',
  styleUrls: ['./step-progress.component.scss'],
})
export class StepProgressComponent {
  // @Input() steps: ProgressStep[] = [];
  @Input() clickable = true;
  @Output() changeStep = new EventEmitter<any>();
  steps$!: Observable<ProgressStep[]>;
  progress$!: Observable<number>;

  mode: ProgressBarMode = 'determinate';
  value = 50;
  bufferValue = 75;
  totalSections: any = 0;

  progressCompleted: any = 0;
  progressPending: any = 0;

  newSteps: any = {
    "progressBars": [],
  }

  constructor(
    private router: Router,
    public gs: GlobalService
  ) { }


  ngOnInit() {
    console.log("yessssssssssss");
    this.getTableData();
    this.steps$ = this.gs.steps$;
    this.progress$ = this.gs.progress$;
  }

  getTableData() {
    const body = {
      "userId": this.gs.loggedInUserInfo.userId,
    }
    this.gs.GetUserProgressBarDetails(body).subscribe(async (response: any) => {
      if (response.response && response.response.statusCode == "200") {
        this.newSteps = response;
        this.totalSections = (100 / this.newSteps.progressBars.length);
        console.log("this.totalSections >>", this.totalSections);

        this.newSteps.progressBars = this.applyActiveStatus(this.newSteps.progressBars);
        const progressWidth: any = {
          "user": {
            "/user/profile": [{ name: "Driver info", pr: 16.67 }],
            "/user/configuration": [{ name: "Driver Details", pr: 50 }],
            "/user/wallet": [],
          },
          "user_2": {
            "/user/profile": [{ name: "Car Owner Info", pr: 16.67 }, { name: "Vehicle Upload", pr: 16.67 }],
            "/user/configuration": [{ name: "Vehicle Other Details", pr: 50 }],
            "/user/wallet": [],
          },
          "user_3": {
            "/user/profile": [{ name: "Company Information", pr: 16.67 }, { name: "Vehicle Upload", pr: 16.67 }],
            "/user/configuration": [{ name: "Vehicle Other Details", pr: 50 }],
            "/user/wallet": [],
          },
          "user_4": {
            "/user/profile": [{ name: "Driver info", pr: 16.67 }, { name: "Vehicle Upload", pr: 16.67 }],
            "/user/configuration": [{ name: "Vehicle Other Details", pr: 50 }, { name: "Driver Details", pr: 50 }],
            "/user/wallet": [],
          },
        }


        for (let i in this.newSteps.progressBars) {
          // if (progressWidth[this.gs.loggedInUserInfo.role] && progressWidth[this.gs.loggedInUserInfo.role][this.newSteps.progressBars[i].route]) {
          //   this.newSteps.progressBars[i].section = progressWidth[this.gs.loggedInUserInfo.role][this.newSteps.progressBars[i].route];
          // }
          // this.totalSections = this.totalSections + this.newSteps.progressBars[i].section?.length;
        }

        console.log("totalSections >>>", this.totalSections);
        console.log("this.newSteps.progressBars >>>", this.newSteps.progressBars);


        this.gs.progressSteps = this.newSteps.progressBars;
      }
    }, (error: any) => {
      this.gs.isSpinnerShow = false;
    })
  }

  applyActiveStatus(steps: any[]): any[] {
    let makeNextActive = false;

    // const progressWidth: any = {
    //   "user": {
    //     "/user/profile": 33.34,
    //     "/user/configuration": 33.33,
    //     "/user/wallet": 33.33,
    //   },
    //   "user_2": {
    //     "/user/profile": 33.33,
    //     "/user/configuration": 50,
    //     "/user/wallet": 16.67,
    //   },
    //   "user_3": {
    //     "/user/profile": 33.33,
    //     "/user/configuration": 50,
    //     "/user/wallet": 16.67,
    //   },
    //   "user_4": {
    //     "/user/profile": 28.58,
    //     "/user/configuration": 57.16,
    //     "/user/wallet": 14.29,
    //   },
    // }



    return steps.map((step, index) => {

      // console.log("step >>>>>", step);


      // if (progressWidth[this.gs.loggedInUserInfo.role] && progressWidth[this.gs.loggedInUserInfo.role][step.route]) {
      //   step.width = progressWidth[this.gs.loggedInUserInfo.role][step.route];
      // }

      // Reset any wrong Active from API
      let status: StepStatus = step.status;
      // progressCompleted
      // progressPending
      if (!step.subBars) {
        if (step.status === 'Completed') {
          this.progressCompleted = (this.progressCompleted + this.totalSections);
        }
      }
      if (step.subBars) {
        if (step.status === 'Completed') {
          this.progressCompleted = (this.progressCompleted + this.totalSections);
        } else {
          for (let i in step.subBars) {
            if (step.subBars[i].isCompleted) {
              const temp = this.totalSections / step.subBars.length
              this.progressCompleted = this.progressCompleted + temp;
              //     this.progressPending
            }
          }
        }
      }

      // if (step.subBars) {
      //   for(let i in step.subBars){
      //     if(step.subBars[i].isCompleted){
      //       this.progressCompleted
      //   //     this.progressPending
      //     }
      //   }
      // }

      if (status === 'Completed') {
        makeNextActive = true;
        return { ...step };
      }

      if (status === 'Partially Completed') {
        makeNextActive = false;
        return { ...step };
      }

      // First Pending after Completed → Active
      if (status === 'Pending' && makeNextActive) {
        makeNextActive = false;
        return { ...step, status: 'Active' };
      }

      return { ...step };
    });
  }

  onProfileCompleted() {
    this.gs.updateStatus('my-profile');
  }

  navigate(step: ProgressStep) {
    if (!this.clickable || !step.route) return;
    this.router.navigate([step.route]);

  }
}
