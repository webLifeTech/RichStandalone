import { Component } from '@angular/core';

@Component({
  selector: 'app-email-verification-success-modal',
  standalone: true,
  imports: [],
  templateUrl: './email-verification-success-modal.component.html',
  styleUrl: './email-verification-success-modal.component.scss'
})
export class EmailVerificationSuccessModalComponent {

}
