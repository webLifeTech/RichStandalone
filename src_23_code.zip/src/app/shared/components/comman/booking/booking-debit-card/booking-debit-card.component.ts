import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-debit-card',
  standalone: true,
  imports: [],
  templateUrl: './booking-debit-card.component.html',
  styleUrls: ['./booking-debit-card.component.scss']
})
export class BookingDebitCardComponent {

}
