import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-cab-filter-skeleton',
  standalone: true,
  imports: [
    CommonModule
  ],
  templateUrl: './cab-filter-skeleton.component.html',
  styleUrl: './cab-filter-skeleton.component.scss'
})
export class CabFilterSkeletonComponent {

}
