import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { GlobalService } from '../../../../../shared/services/global.service';

@Component({
  selector: 'app-dynamic-info-modal',
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule
  ],
  providers: [
    NgbActiveModal,
  ],
  templateUrl: './dynamic-info-modal.component.html',
  styleUrl: './dynamic-info-modal.component.scss'
})
export class DynamicInfoModalComponent {
  @Input() driverInfoData: any = {};
  @Input() groupedSectionsData: any = {};

  constructor(
    private modalService: NgbModal,
    public gs: GlobalService
  ) {
  }

  ngOnInit() {
    console.log("1111111 groupedSectionsData >>>>>>>", this.groupedSectionsData);
    console.log("1111111 driverInfoData >>>>>>>", this.driverInfoData);

    for (let topRow in this.groupedSectionsData) {
      const formArray = this.groupedSectionsData[topRow].fields
      for (let i in formArray) {
        formArray[i].isOpen = false;

        if (formArray[i].modalObject) {
          const endKey = formArray[i].fieldType === 'TEXTMASK' ? formArray[i].modalValueCode : formArray[i].modalValue;
          console.log("endKey >>>", endKey);


          formArray[i].modalObject = formArray[i].modalObject + '.' + endKey;
          formArray[i].defaultValue = this.resolveNestedValue(formArray[i].modalObject, this.driverInfoData);
          console.log("this.value >>>>>>>", formArray[i].defaultValue);
        }
      }
    }
  }

  resolveNestedValue(path: string, obj: any): any {
    const keys = path.split('.');

    return keys.reduce((acc, key) => {
      if (Array.isArray(acc)) {
        const match = key.match(/(\w+)\[(\d+)\]/);
        if (match) {
          const index = parseInt(match[2], 10); // e.g., 0
          return acc.find((item, idx) => idx === index) || null;
        }
      }
      return acc && acc[key] !== undefined ? acc[key] : null;
    }, obj);
  }

  closeModal() {
    this.modalService.dismissAll();
  }

}
