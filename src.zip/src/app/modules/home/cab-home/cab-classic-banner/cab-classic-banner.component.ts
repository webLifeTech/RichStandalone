import { Component } from '@angular/core';
// import { SharedModule } from '../../../../shared/shared.module';

@Component({
  selector: 'app-cab-classic-banner',
  standalone: true,
  imports: [
    // SharedModule
  ],
  templateUrl: './cab-classic-banner.component.html',
  styleUrls: ['./cab-classic-banner.component.scss']
})
export class CabClassicBannerComponent {

}
