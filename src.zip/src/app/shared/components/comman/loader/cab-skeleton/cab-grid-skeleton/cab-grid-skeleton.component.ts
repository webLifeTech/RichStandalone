import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-cab-grid-skeleton',
  standalone: true,
  imports: [
    CommonModule
  ],
  templateUrl: './cab-grid-skeleton.component.html',
  styleUrl: './cab-grid-skeleton.component.scss'
})
export class CabGridSkeletonComponent {

}
