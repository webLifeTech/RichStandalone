import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-animation-bird',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './animation-bird.component.html',
  styleUrls: ['./animation-bird.component.scss']
})
export class AnimationBirdComponent {

}
