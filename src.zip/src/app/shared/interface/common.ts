export interface usaStates {
    id: number;
    name: string;
    value: string;
    icon: string;
}