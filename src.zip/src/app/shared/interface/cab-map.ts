export interface cabMap{
  cab: number[];
}
